//Mehul Varma
//mvarma4
//CMPS-12B/M
//charType.c
//code for sorting the input to different categories



#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<assert.h>
#include<string.h>

#define MAX_STRING_LENGTH 100

void extract_chars(char* s, char* a, char* d, char* p, char* w);


int main(int argc, char* argv[]){
	FILE* in;                          
	FILE* out;                        
	char *line;                    
	char *alpha;     
	char *digits;
	char *punc;
	char *whitesp;
 
	if( (in=fopen(argv[1], "r"))==NULL ){
		printf("Unable to read from file %s\n", argv[1]);
		exit(EXIT_FAILURE);
	}

	if( (out=fopen(argv[2], "w"))==NULL ){
		printf("Unable to write to file %s\n", argv[2]);
		exit(EXIT_FAILURE);
	}


	line = calloc(MAX_STRING_LENGTH+1, sizeof(char) );
	alpha = calloc(MAX_STRING_LENGTH+1, sizeof(char) );
	digits = calloc(MAX_STRING_LENGTH+1, sizeof(char) );
	punc = calloc(MAX_STRING_LENGTH+1, sizeof(char) );
	whitesp = calloc(MAX_STRING_LENGTH+1, sizeof(char) );

	assert( line!=NULL && alpha!=NULL && digits!=NULL && punc!=NULL && whitesp!=NULL );

	int num_line = 1;
	while( fgets(line, MAX_STRING_LENGTH, in) != NULL ){
		extract_chars(line, alpha, digits, punc, whitesp);
		int al = strlen(alpha);
		int di = strlen(digits);
		int pu = strlen(punc);
		int ws = strlen(whitesp);
		fprintf(out, "line %d contains:\n", num_line);

		if ( al > 1) fprintf(out, "%d alphabetic charecters: %s\n", al , alpha); 
		else fprintf(out, "%d alphabetic charecter: %s\n", al , alpha);

		if ( di > 1) fprintf(out, "%d numeric charecters: %s\n", di , digits);
		else fprintf(out, "%d numeric charecter: %s\n", di , digits);

		if ( pu > 1) fprintf(out, "%d punctuation charecters: %s\n", pu , punc); 
		else fprintf(out, "%d punctuation charecter: %s\n", pu , punc);

		if ( ws > 1) fprintf(out, "%d whitespace charecters: %s\n", ws , whitesp); 
		else fprintf(out, "%d whitespace charecter: %s\n", ws , whitesp );

		num_line++ ;
	}

	free(line);
	free(alpha);
	free(digits);
	free(punc);
	free(whitesp);

	fclose(in);
	fclose(out);

	return EXIT_SUCCESS;
}

void extract_chars(char *s, char *a, char *d, char *p, char *w){

	int i=0, j=0;

	while(s[i]!='\0' && i<MAX_STRING_LENGTH){
		if( isalpha( (int) s[i]) ) a[j++] = s[i];
		i++;
	}
	a[j] = '\0';

	i=0;
	j=0;

	while(s[i]!='\0' && i<MAX_STRING_LENGTH){
		if( isdigit( (int) s[i]) ) d[j++] = s[i];
		i++;
	}
	d[j] = '\0';

	i=0;
	j=0;

	while(s[i]!='\0' && i<MAX_STRING_LENGTH){
		if( ispunct( (int) s[i]) ) p[j++] = s[i];
		i++;
	}
	p[j] = '\0';

	i=0;
	j=0;

	while(s[i]!='\0' && i<MAX_STRING_LENGTH){
		if( isspace( (int) s[i]) ) w[j++] = s[i];
		i++;
	}
	w[j] = '\0';

}


