//Mehul Varma
//mvarma4
//CMPS-12b/m
//README.txt
//lists all the files in the folder
charType
charType.c
charType.o
in
out
Makefile
README.txt
